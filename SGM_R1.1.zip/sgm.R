#LI Wu (liwu@staff.shu.edu.cn). Shanghai University. Mathematical Economics. updated: 201405

#Compute the PF eigvalue and eigvector.
PF_eig<-function (M) 
{
  ev<-eigen(M) 
  
  tmp<-Re(ev$values)
  
  indx<-which(tmp==max(tmp))
  if (length(indx)!=1){ 
    print(M);   print(ev$values); print(indx)
    stop("Li:PF_eig, none or multiple PF eig value")
  }

  PFVector<-ev$vectors[,indx]    
  PFVector<-PFVector/sum(PFVector)
  list(val=abs(ev$values[indx]),vec=abs(PFVector))
}


dg<-function (x){
  if (length(x)==1) return(x)
  if (is.vector(x)||nrow(x)==1||ncol(x)==1) return(diag(c(x)))
  else return(diag(x))
}


F_Z<-function (A,p,S){
  s<-rowSums(S)
  S_bar<-S
  m<-ncol(S)
  for (tk in 1:length(s)) {
    if (s[tk]!=0) S_bar[tk,]<-S_bar[tk,]/s[tk]  
  }
  
  Z<-dg(1/(t(p)%*%A))%*%t(S_bar)%*%dg(p)%*%A
  
  tmp<-PF_eig(Z)
  z_structure<-tmp$vec
  
  zeta<-min(s/(A%*%z_structure))
  z=zeta*z_structure;
  q=A%*%z/s
  list(z=z,q=q)
}

xNext<-function (xt,param){
  p_t<-xt$p
  S_t<-xt$S
  q_t<-xt$q
  z_t<-xt$z
  e_t<-xt$e 
  with(param,{
    if (all(is.na(e_t)))  e_tp1<-NA
    
    p_tp1<-p_t
    switch(priceAdjustmentMethod,
           'fixed'={for (ka in 1:ncommod){
               if (q_t[ka]<=thresholdForPriceAdjustment)
                 p_tp1[ka]<-p_t[ka]*(1-priceAdjustmentVelocity)
               else
                 p_tp1[ka]<-p_t[ka]
               
             }
             p_tp1<-p_tp1/sum(p_tp1)  #normalize
           },
           'variable'={
             p_tp1<-p_t*(1-priceAdjustmentVelocity*(1-q_t))
             
             if (any(!is.na(pExg))){
               tmpIndx<-which(!is.na(pExg))
               tmpIndx<-tmpIndx[1]
               p_tp1<-p_tp1/p_tp1[tmpIndx]*pExg[tmpIndx]
               p_tp1[!is.na(pExg)]<-pExg[!is.na(pExg)]
             }
             else {
               p_tp1<-p_tp1/sum(p_tp1)  #normalize
             }
           },
           'monetary'={ #monetary economy
             p_tp1<-p_t*(1-priceAdjustmentVelocity*(1-q_t))
             e_tp1<-e_t*(1-priceAdjustmentVelocity*(1-q_t[moneyIndx])) 
             
             p_tp1<-p_tp1/e_tp1[1]
             e_tp1<-e_tp1/e_tp1[1]
             
             if (!is.null(pExg)&&length(pExg)!=0)
               p_tp1[!is.na(pExg)]<-pExg[!is.na(pExg)]
           },
           
           'stock'={#201601
             #tmp.theta<- priceAdjustmentVelocity+mean((1-q_t))
             
             q_t<-round(q_t,6)
             p_tp1<-p_t*(1-priceAdjustmentVelocity*(1-q_t)^kurtosisCoef) 
             
             p_tp1<-p_tp1/sum(p_tp1)  #normalize
           },
           
           
           stop("LI: Wrong priceAdjustmentMethod!,xnext")
    )#switch
    
    
    if (is.numeric(B))  B_t<-B
    else  B_t<-B(list(p=p_t,z=z_t,t=time-1))
    
    S_tp1<-(B_t%*%dg(z_t)+depreciationCoef*dg(1-q_t)%*%S_t)
    
    if (all(is.na(S0Exg))) { }#Set exogenous supply
    else {S_tp1[!is.na(S0Exg)]<-S_t[!is.na(S0Exg)]*(1+GRExg)
          
    if (any(!is.na(e_t))){
      for (i in 1:length(e_t))
        S_tp1[moneyIndx[i],moneyOwnerIndx[i]]<-S_tp1[moneyIndx[i],moneyOwnerIndx[i]]/e_t[i]*e_tp1[i]
    }
    }

    if (is.numeric(A)) A_tp1<-A
    else A_tp1<-A(list(p=p_tp1,z=z_t,w=t(p_tp1)%*%S_tp1,t=time,e=e_tp1)) #20140614,add e
    
    tmp<-F_Z(A_tp1,p_tp1,S_tp1)
    q_tp1<-tmp$q
    z_tp1<-tmp$z
    
    if (any(z_tp1<0)){
      if (any(z_tp1[z_tp1<0]>-0.01)){
        z_tp1[z_tp1<0]<-0;
        warning("LI:negative_z,z_tp1<0")
      }
      else{
        print(z_tp1)
        stop("Li: negative_z")
      }
    }

    list(p=p_tp1,S=S_tp1,q=q_tp1,z=z_tp1,e=e_tp1)

  })#with
  
}#xNext



sgm<-function (param){
  #computing general economic equilibrium by the structural growth model.
  result<-c()

  #default values for econParam
  if (is.null(param$GRExg)) param$GRExg<-NA
  if (is.null(param$moneyOwnerIndx)) param$moneyOwnerIndx<-NA
  if (is.null(param$moneyIndx)) param$moneyIndx<-NA
  if (is.null(param$pExg)) param$pExg<-NA
  
  if (is.null(param$tolCond)) param$tolCond<-1e-5
  
  if (is.null(param$iterationCount)) param$iterationCount<-200 
  if (is.null(param$numberOfPeriods)) param$numberOfPeriods<-300
  if (is.null(param$depreciationCoef)) param$depreciationCoef<-0.8
  if (is.null(param$thresholdForPriceAdjustment)) param$thresholdForPriceAdjustment<-0.99
  if (is.null(param$priceAdjustmentMethod)) param$priceAdjustmentMethod<-'variable'
  if (is.null(param$priceAdjustmentVelocity)) param$priceAdjustmentVelocity<-0.15
  if (is.null(param$priceAdjustmentVelocityCoefficient)) param$priceAdjustmentVelocityCoefficient<-0.95
  if (is.null(param$substitutionMethod)) param$substitutionMethod<-'finalValue'
  if (is.null(param$showIterationNumber)) param$showIterationNumber<-0
  if (is.null(param$enableDisp)) param$enableDisp<- -1
  
  if (is.null(param$B))  param$B<-diag(nrow(param$A))
  if (is.null(param$ncommod)) { 
    param$ncommod<-nrow(param$B)
    param$m<-ncol(param$B)
  }
  
  if (is.null(param$S0Exg)) param$S0Exg<-matrix(NA,param$ncommod,param$m)
  
  if (is.null(param$p0)) param$p0<-matrix(1,nrow=param$ncommod,ncol=1)
  if (is.null(param$z0)) param$z0<-matrix(100,nrow=param$m,ncol=1)
  
  
  with(param,{
    if (enableDisp)  print(paste("tolCond: ", tolCond))
    
    p<-matrix(0,ncommod,numberOfPeriods)
    S<-array(0,dim=c(ncommod,m,numberOfPeriods))
    q<-matrix(0,ncommod,numberOfPeriods)
    z<-matrix(0,m,numberOfPeriods)
    if (length(moneyIndx)>1)
      e<-matrix(0,length(moneyIndx),numberOfPeriods)
    else
      e<-matrix(0,1,numberOfPeriods)
    
    if (all(is.na(S0Exg)))
      S0<-matrix(0,ncommod,m)
    else {
      S0<-S0Exg
      S0[is.na(S0)]<-0
    }
    
    firstExgSupplyIndx<-which(!is.na(c(S0Exg)))[1] #Here we may get NA, not empty!
    
    if (!is.null(param$moneyIndx)&&!is.na(param$moneyIndx)){
      param$priceAdjustmentMethod<-'monetary' #for monetary economy
      
      e0<-matrix(1,length(moneyIndx),1)
    }
    else e0<-NA
    
    time<-1;
    xtp1<-xNext(list(p=p0,S=S0,q=matrix(1,ncommod,1),z=z0,e=e0),param);
    p[ ,1]<-xtp1$p
    S[ , ,1]<-xtp1$S
    q[ ,1]<-xtp1$q
    z[ ,1]<-xtp1$z
    e[ ,1]<-xtp1$e
    
    
    toleranceCoefficientRec<-matrix(1,iterationCount,1)
    
    for (k in 1:iterationCount){
      for (t in 2:numberOfPeriods){
        xt<-c()
        xt$p<-p[,t-1]
        xt$S<-S[ , ,t-1]
        xt$q<-q[,t-1]
        xt$z<-z[,t-1]
        xt$e<-e[,t-1]
        
        xtp1<-xNext(xt,param)
        p[ ,t]<-xtp1$p
        S[ , ,t]<-xtp1$S
        q[ ,t]<-xtp1$q
        z[ ,t]<-xtp1$z
        e[ ,t]<-xtp1$e
        
        
        time<-time+1;
      } # for (t in 2:numberOfPeriods)
      
      if (showIterationNumber==k){
        result$ts_p<-p
        result$ts_z<-z
        result$ts_S<-S
        result$ts_q<-q
        result$ts_e<-e
        
        par(mfrow=c(2,1))
        plot(p[1,],ylim=c(min(p)*0.95,max(p)*1.05),type="l",ylab="p")
        for (k.row in 2:nrow(p)) {
          lines(p[k.row,],lty=k.row)
        }
        plot(z[1,],ylim=c(min(z)*0.95,max(z)*1.05),type="l",ylab="z")
        for (k.row in 2:nrow(z)) {
          lines(z[k.row,],lty=k.row)
        }
      }
      
      tmp1<-z[ ,ncol(z)]/max(z[ ,ncol(z)])
      tmp2<-z[ ,ncol(z)-1]/max(z[ ,ncol(z)-1])
      toleranceCoefficientZ<-max(abs(tmp1-tmp2))    
      
      tmpU<-apply(q[ ,(ncol(q)-20):ncol(q)],1,min)
      tmpU<-tmpU[p[ ,ncol(p)]>tolCond] 
      toleranceCoefficientU<-max(1-tmpU)
      toleranceCoefficient<-max(c(toleranceCoefficientU, toleranceCoefficientZ))
      toleranceCoefficientRec[k]<-toleranceCoefficient
      
      if ((k>=5&&(toleranceCoefficientRec[k]/toleranceCoefficientRec[k-1]>0.9))||toleranceCoefficient>0.99){ #converge slowly
        if (!is.na(GRExg)&&GRExg==0)
          substitutionMethod<-'meanValue'
        else
          substitutionMethod<-'pMeanValue'
        
        print(paste(k,', substitutionMethod: ',substitutionMethod))
        
        
        if (k>10&&(toleranceCoefficientRec[k]/toleranceCoefficientRec[k-1]>0.95))
          priceAdjustmentVelocity<-priceAdjustmentVelocity*priceAdjustmentVelocityCoefficient
        
      }
      
      
      if (GRExg==0&&toleranceCoefficientU<tolCond&&toleranceCoefficientZ>=tolCond){
        substitutionMethod<-'zMeanValue'
        print(paste('substitutionMethod: ',substitutionMethod))
      }
      
      S0<-S[ , ,dim(S)[3]]
      switch (substitutionMethod,
              'pMeanValue'={p0<-apply(p,1,mean)
                #print(paste("p0:",p0))
                },
              'zMeanValue'={z0<-apply(z,1,mean)},
              'meanValue'={
                p0<-apply(p,1,mean)
                z0<-apply(z,1,mean)
                #print(paste("p0:",p0))
                #print(paste("z0:",z0))
              },
              'finalValue'={p0<-p[ ,ncol(p)]
              z0<-z[ ,ncol(z)]
              S0<-S[ , ,dim(S)[3]]},
              stop('Li: wrong substitutionMethod!')
      )
    
    if (!is.na(firstExgSupplyIndx)){ #There are exogenous supplies.
      z0<-z0/S0[firstExgSupplyIndx]*S0Exg[firstExgSupplyIndx]
      S0<-S0/S0[firstExgSupplyIndx]*S0Exg[firstExgSupplyIndx]
    }
    else{
      S0<-S0/max(z0) 
      z0<-z0/max(z0)
    }
    
    if (enableDisp)
      print(paste('Iteration number ', k, ': tolerance coefficient ', toleranceCoefficient))
    
    if (toleranceCoefficient<tolCond)     break
    
    
    xtp1<-xNext(list(p=p0,S=S0,q=matrix(1,ncommod,1),z=z0,e=t(tail(t(e),1))),param)
    p[ ,1]<-xtp1$p
    S[ , ,1]<-xtp1$S
    q[ ,1]<-xtp1$q
    z[ ,1]<-xtp1$z
    e[ ,1]<-xtp1$e
  }#for (k in 1:iterationCount){
  
  result$toleranceCoefficient<-toleranceCoefficient
  result$p<-p0;    result$z<-z0;    result$S<-S0;
  if (any(!is.na(e0))) result$ex<-t(tail(t(e),1))
  if (all(is.na(S0Exg))) result$growthRate<-max(z[ ,ncol(z)])/max(z[ ,ncol(z)-1])-1
  
  if (is.numeric(A))
    result$A<-A
  else{
    tmpS<-S0Exg;#Here need change?
    tmpS[is.na(tmpS)]<-0
    result$A<-A(list(p=result$p,z=result$z,w=result$p%*%tmpS,t=time,ex=result$ex))#20140614,add e
  }
  result
  }) #with
  


}#fun sgm



CD_A<-function(a,b,p) {
  #computing Cobb-Douglas input coefficient matrix
  if (is.numeric(b)&&any(abs(colSums(b)-1)>10^-10))
    stop('Li: sum(b)~=1, CD_A')
  
  A<-dg(1/p)%*%b%*%dg(apply((dg(1/p)%*%b)^(-b),2,prod)%*%dg(1/a));
}

CES_A<-function(sigma,a,B,p){
  #computing CES input coefficient matrix
  n<-nrow(B)
  m<-ncol(B)
  
  A<-matrix(0,n,m)
  #if isnumeric(sigma)&&isnumeric(a)&&isnumeric(B)&&isnumeric(p)
  #else
  #  A=sym(zeros(n,m));
  #end;
  
  for (cn in 1:m){
    e1<-1/(1-sigma[cn]);
    e2<-sigma[cn]/(sigma[cn]-1);
    e3<--1/sigma[cn];
    k<-a[cn];
    beta<-B[ ,cn];
    for (rn in 1:n){
      A[rn,cn]<-1/k* (beta[rn]/p[rn])^e1 * (sum(beta^e1*p^e2)) ^e3
    }
  }
  A
}

Leontief_mA<-function(A,p){ 
  #computing Leontief input coefficient matrix in a monetary economy
  nonnegativeA<-A;
  nonnegativeA[nonnegativeA<0]<-0;
  Indx<-which(A<0, arr.ind=T)
  for (k in 1:nrow(Indx))
    A[Indx[k,1],Indx[k,2]]<-t(p)%*%nonnegativeA[ ,Indx[k,2]]/(-A[Indx[k,1],Indx[k,2]]);

  A
}

CD_mA<-function(a,b,p) {
  #computing Cobb-Douglas input coefficient matrix in a monetary economy
  nonnegative_b<-b;
  nonnegative_b[b<0]<-0;
  A<-CD_A(a,nonnegative_b,p);
  tmpA<-A;
  
  Indx<-which(b<0, arr.ind=T)
  for (k in 1:nrow(Indx)){
    A[Indx[k,1],Indx[k,2]]<-t(p)%*%tmpA[ ,Indx[k,2]]/(-b[Indx[k,1],Indx[k,2]]);
  }
  A
}
CES_mA<-function(sigma,a,b,p){
  #computing CES input coefficient matrix in a monetary economy
  nonnegative_b<-b;
  nonnegative_b[b<0]<-0;
  A<-CES_A(sigma,a,nonnegative_b,p);
  tmpA<-A;
  
  Indx<-which(b<0, arr.ind=T)
  for (k in 1:nrow(Indx)){
    A[Indx[k,1],Indx[k,2]]<-t(p)%*%tmpA[ ,Indx[k,2]]/(-b[Indx[k,1],Indx[k,2]]);
  }
  A
}