#LI Wu (liwu@staff.shu.edu.cn). Shanghai University. Mathematical Economics.
#C-D pure production
Example2.2<-function(){
  param<-c()

  alpha<-rbind(5,3,1)
  Beta<-matrix(c(0.6, 0.4,  0.2,
                 0.1,  0.4,  0.7,
                 0.3,  0.2,  0.1),3,3,TRUE)
  
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(3)
  sgm(param)
}

#von Neumann-type economy
Example2.3<-function(){
  param<-c()
  param$A<-matrix(c(0.8, 0.5, 0.06,
               2, 2, 0.4),2,3,T)
  param$B<-matrix(c(1, 1, 0,
               0, 0, 1),2,3,T)
  sgm(param)
}


#Setion 3.1.2, Leontief-type two-sector corn economy
Example.Section.3.1.2.corn<-function(){
  param<-c()
  param$A<-matrix(c(0.5,1,
                    1,  0),2,2,TRUE)
  param$B<-diag(2)
  param$S0Exg<-matrix(c(NA, NA,
                        NA, 100),2,2,TRUE)      
  param$GRExg<-0
  sgm(param)
}

#two-sector corn economy with non-homothetic utility function
Example3.1<-function(){
  param<-c()
  param$GRExg<-0.2
  rho<-1/(1+param$GRExg)
  param$A<-function(state){
    with(state,{ 
      matrix(c(0.5, (-1/2*(p[2]-(p[2]^2+4*p[1]*p[2]*rho)^(1/2))/p[1])^2,
               1,  -1/2*(p[2]-(p[2]^2+4*p[1]*p[2]*rho)^(1/2))/p[1]),2,2,T)
    })
  }
  param$B<-diag(2)
  param$S0Exg<-matrix(c(NA, NA,
                        NA, 100),2,2,TRUE) 
  sgm(param)
}


#C-D-type two-sector corn economy
Example3.2<-function(){
  param<-c()
  
  alpha<-rbind(1,1)
  Beta<-matrix(c(0.5, 0.4,
                 0.5, 0.6),2,2,TRUE)
  
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(2)
  param$S0Exg<-matrix(c(NA, NA,
                        NA, 100),2,2,TRUE) 
  param$GRExg<-0
  sgm(param)
}


#Lontief-type three-sector economy with one primary factor
Example3.4<-function(){
  param<-c()
  
  param$A<-matrix(c(0, 0.4, 1,
  0.5, 0, 0,
  0.3, 0.4, 0),3,3,T)
  param$B<-diag(3)
  param$S0Exg<-matrix(NA,3,3) 
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  sgm(param)
}

#C-D-type three-sector economy with one primary factor
Example3.8<-function(){
  param<-c()
  
  alpha<-rbind(5,3,1)
  Beta<-matrix(c(0.6, 0.4, 0.2,
                 0.1, 0.4, 0.7,
                 0.3, 0.2, 0.1),3,3,TRUE)
  
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(3)
  param$S0Exg<-matrix(NA,3,3) 
  param$S0Exg[3,3]<-100
  #Iron is both product and primary factor.
  #(ii) param$S0Exg[2,3]<-100
  #(iii) param$S0Exg[2,3]<- -1
  param$GRExg<-0
  sgm(param)
}

#C-D-type three-sector economy with two primary factors
Example3.9<-function(){
  param<-c()
  
  alpha<-rbind(5,3,1)
  Beta<-matrix(c(0.6, 0.4, 0.2,
                 0.1, 0.4, 0.7,
                 0.3, 0.2, 0.1),3,3,TRUE)
  
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(3)
  param$S0Exg<-matrix(NA,3,3) 
  param$S0Exg[2,2]<-60
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  sgm(param)
}


#Leontief-type corn economy with three primary factors
Example3.10<-function(){
  param<-c()
  
  param$A<-matrix(c(0, 0, 1, 1, 1,
                    0.5, 1, 0, 0, 0,
                    0.5, 0, 0, 0, 0,
                    0, 1, 0, 0, 0),4,5,TRUE)
  param$B<-matrix(c(1, 1, 0, 0, 0,
                    0, 0, 1, 0, 0,
                    0, 0, 0, 1, 0,
                    0, 0, 0, 0, 1),4,5,TRUE)
  param$S0Exg<-matrix(NA,4,5) 
  param$S0Exg[2,3]<-30
  param$S0Exg[3,4]<-20
  param$S0Exg[4,5]<-20
  param$GRExg<-0
  sgm(param)
}

#decreasing returns to scale
Example3.12<-function(){
  param<-c()
  
  param$A<-function(state){
    with(state,{ 
      matrix(c(0, 0, (w[3]/10000-0.4*p[3])/(3*p[1]),
                0, 0, (w[3]/10000-0.4*p[3])/(3*p[2]),
                (p[4]/p[3])^0.5, 0.5*(p[5]/p[3])^0.5, 0.4+(w[3]/10000-0.4*p[3])/(3*p[3]),
                (p[4]/p[3])^(-0.5), 0, 0,
                0, 0.5*(p[5]/p[3])^(-0.5), 0),5,3,T)
    })
  }
  param$B<-matrix(c(1, 0, 0,
                    0, 1, 0,
                    0, 0, 1,
                    0, 0, 1/10000,
                    0, 0, 1/10000),5,3,TRUE)
  param$S0Exg<-matrix(NA,5,3) 
  param$S0Exg[3,3]<-10000
  param$S0Exg[4,3]<-1
  param$S0Exg[5,3]<-1
  param$GRExg<-0
  sgm(param)
}

#regular economy and pure exchange economy
Example3.14<-function(){
  param<-c()
  
  alpha<-rbind(1,1)
  Beta<-matrix(c(0.5, 0.75,
                 0.5, 0.25),2,2,TRUE)
  
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(2)
  param$S0Exg<-matrix(c(60,0,
                        0,100),2,2,T) 
  param$GRExg<-0
  sgm(param)
}

#non-sufficient supply of the primary factor
Example4.2<-function(){
  param<-c()
  sigma<-rbind(-1,-1,-1)
  alpha<-rbind(1,1,1)
  Beta<-matrix(c(0, 1, 1,
                 1, 0, 0,
                 1, 0, 0),3,3,TRUE)
  
  param$A<-function(state){CES_A(sigma,alpha,Beta,state$p)}
  param$B<-diag(3)
  param$S0Exg<-matrix(c(NA,NA,NA,
                        NA,100,NA,
                        NA,NA,100),3,3,T) 
  param$GRExg<-0
  sgm(param)
}

#increasing returns to scale
Example4.8<-function(){
  alpha<-rbind(1,1)
  Beta<-matrix(c(
    0.5,   1,
    0.5,   0),2,2,TRUE)
  
  param<-c()
  param$A<-function(state){
    CD_A(alpha,Beta,state$p)%*%diag(c(state$z[1]^(-1/4), 1))
  }
  param$B<-diag(2)
  param$S0Exg<-matrix(c(
    NA, NA,
    NA, 100),2,2,TRUE)
  param$GRExg<-0   
  sgm(param)
}

#price signal
Example4.9<-function(){
  alpha<-rbind(1,1)
  Beta<-matrix(c(
    0.5,   0.4,
    0.5,   0.6),2,2,TRUE)
  
  param<-c()
  param$A<-function(state){
    CD_A(alpha,Beta,state$p)%*%diag(c(state$z[1]^(-1/4), 1))
  }
  param$B<-diag(2)
  param$S0Exg<-matrix(c(
    NA, NA,
    NA, 100),2,2,TRUE)
  param$GRExg<-0  
  sgm(param)
}

#tax
Example4.10<-function(){
  alpha<-rbind(5,3,1)
  Beta<-matrix(c(
    0.6,  0.4,  0.2,
    0.1,  0.4,  0.7,
    0.3,  0.2,  0.1,
    0,    0,    0),4,3,TRUE)
  
  tau<-0.1
  Tax<-matrix(c(
    0, 0, 0,
    0, 0, 0,
    0, 0, 0,
    0, tau/(1+tau), 0),4,3,TRUE)
  
  param<-c()
  param$A<-function(state){CD_A(alpha,Beta,state$p)+state$p[2]*Tax/state$p[4]}
  param$B<-matrix(c(
    1, 0, 0,
    0, 1, 0,
    0, 0, 1,
    1, 0, 0),4,3,TRUE)
  
  param$S0Exg<-matrix(NA,4,3)
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  sgm(param)
}

Example4.11.1<-function(){
  tau<-1
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,3,3)
    result[1:2,1]<-CD_A(1,rbind(0.5,0.5),state$p[1:2])
    #result[3,1]<-state$p[1]*tau/(1+tau)/state$p[3]
    result[3,1]<-tau*(state$p[1]*result[1,1]+
                        state$p[2]*result[2,1])/state$p[3]
    
    result[1:2,2]<-CD_A(1,rbind(0.5,0.5),state$p[1:2])
    result[3,2]<-0
    
    result[,3]<-c(1,0,0)
    
    result
    }
  param$B<-matrix(c(
    1, 0, 0,
    0, 1, 1,
    0, 0, 1),3,3,TRUE)
  
  param$S0Exg<-matrix(c(NA,NA,NA,
                        NA,100,100,
                        NA,NA,100),3,3,T)
  param$GRExg<-0
  sgm(param)
}

Example4.11.2<-function(){
  tau<-1
  param<-c()
  
  param$A<-function(state){
    result<-matrix(NA,3,3)
    result[1:2,1]<-CD_A(1,rbind(0.5,0.5),state$p[1:2])
    result[3,1]<-0
    
    
    result[1:2,2]<-CD_A(1,rbind(0.5,0.5),state$p[1:2])
    result[3,2]<-(state$p[1]*result[1,1]+state$p[2]*result[2,1])*tau/state$p[3]
    
    result[,3]<-c(1,0,0)
    
    result
  }
  param$B<-matrix(c(
    1, 0, 0,
    0, 1, 1,
    0, 0, 1),3,3,TRUE)
  
  param$S0Exg<-matrix(c(NA,NA,NA,
                        NA,100,100,
                        NA,NA,100),3,3,T)
  param$GRExg<-0
  sgm(param)
}

Example4.12<-function(){
  tau<-1
  param<-c()
  
  param$A<-function(state){
    result<-matrix(NA,3,3)
    result[1:2,1]<-CD_A(1,rbind(0.5,0.5),rbind(state$p[1],state$p[2]*(1+tau)))
    result[3,1]<-state$p[2]*result[2,1]*tau/state$p[3]
    
    result[1:2,2]<-CD_A(1,rbind(0.5,0.5),state$p[1:2])
    result[3,2]<-0
    
    result[,3]<-c(1,0,0)
    
    result
  }
  param$B<-matrix(c(
    1, 0, 0,
    0, 1, 0,
    0, 0, 100),3,3,TRUE)
  
  param$S0Exg<-matrix(c(NA,NA,NA,
                        NA,200,NA,
                        NA,NA,100),3,3,T)
  param$GRExg<-0
  sgm(param)
}

#divident
Example4.13<-function(){
  r<-0.25

  param<-c()
  
  param$A<-function(state){
    result<-matrix(NA,3,3)
    result[1:2,1]<-CD_A(1,rbind(0.5,0.5),state$p[1:2])
    result[3,1]<-r*(state$p[1]*result[1,1]+state$p[2]*result[2,1])/state$p[3]
    
    result[,2]<-c(1,0,0)
    result[,3]<-c(1,0,0)
    
    result
  }
  
  param$B<-diag(3)
  param$S0Exg<-matrix(c(NA,NA,NA,
                        NA,100,NA,
                        NA,NA,100),3,3,T)
  param$GRExg<-0
  sgm(param)
}

#over-investment
Example4.15<-function(){
  param<-c()

  param$A<-function(state){
    result<-matrix(NA,2,2)
    result[,1]<-CD_A(1,rbind(0.5,0.5),state$p)
    result[,2]<-c(1,0)
    
    result
  }
  
  param$B<-diag(2)
  param$S0Exg<-matrix(c(NA,NA,
                        75,25),2,2,T)
  param$GRExg<-0
  sgm(param)
}

#technology monopoly
Example4.16<-function(){
  param<-c()
  
  alpha<-rbind(1,1.5)
  Beta<-matrix(c(0.5, 0.5,
                 0.5,  0.5),2,2,TRUE)
  
  param$A<-function(state){
    result<-matrix(0,3,4)
    result[1:2,1:2]<-CD_A(alpha,Beta,state$p[1:2])
    result[3,2]<-1
    result[1:3,3]<-result[1:3,4]<-c(1,0,0)
    result
  }
  param$B<-matrix(c(1, 1, 0, 0,
                    0, 0, 1, 0,
                    0, 0, 0, 1),3,4,TRUE)
  param$S0Exg<-matrix(c(NA, NA, NA, NA,
                        NA, NA, 100, NA,
                        NA, NA, NA, 99.99),3,4,TRUE)     
  param$GRExg<-0
  sgm(param)
}

#fixed assets
Example5.1<-function(){
  param<-c()
  
  param$A<-matrix(c(0.5, 0.9, 0.5, 0.5,
                    0.6, 0, 0, 0,
                    0, 0, 0.6, 0,
                    0, 0, 0, 0.6),4,4,TRUE)
  param$B<-matrix(c(1, 0, 1, 1,
                    0, 1, 0, 0,
                    0.6, 0, 0, 0,
                    0, 0, 0.6, 0),4,4,TRUE)
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

#fixed assets
Example5.2<-function(){
  param<-c()
  
  param$A<-matrix(c(0.5, 0.9,
                    0.6, 0),2,2,TRUE)
  param$B<-matrix(c(1, 0,
                    0.4, 1),2,2,TRUE)
  sgm(param)
}

#fixed assets
Example5.3.1<-function(){
  param<-c()
  
  param$A<-matrix(c(0.6, 0.4, 1,
                    0.1, 0.4, 0,
                    0.3, 0.2, 0),3,3,TRUE)
  param$B<-diag(3)
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  sgm(param)
}

#fixed assets
Example5.3.2<-function(){
  param<-c()
  
  param$A<-matrix(c(0.6, 0.4, 1,
                    0.1, 0.4, 0,
                    0.3, 0.2, 0),3,3,TRUE)
  
  param$GRExg<-0
  v<-1/(2+param$GRExg)
  param$B<-matrix(c(1, 0, 0,
                    0.1*(1-v), 1+0.4*(1-v), 0,
                    0, 0, 1),3,3,T)
  
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[3,3]<-100

  sgm(param)
}

#fixed assets
Example5.4<-function(){
  param<-c()
  param$GRExg<-0.1
  v<-1/(2+param$GRExg)
  param$A<-matrix(c(0.6, 0.4, 1, 0,
                    0, 0, 0, 1/(1+param$GRExg),
                    0.3, 0.2, 0, 0,
                    0.1, 0.4, 0, 0),4,4,T)
  param$B<-matrix(c(1, 0, 0, 0,
                    0, 1, 0, (1-v)/(1+param$GRExg),
                    0, 0, 1, 0,
                    0, 0, 0, 1),4,4,TRUE)
  param$S0Exg<-matrix(NA,4,4)
  param$S0Exg[3,3]<-100
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

#fixed assets
Example5.5<-function(){
  param<-c()
  param$GRExg<-0.1
  rdm<-0.1
  rho<-1/(1+param$GRExg)

  param$A<-function(state){
    result<-matrix(NA,6,5)
    result[1:5,]<-matrix(c(0.6, 0.4, 1, 0, 0, 
                           0, 0, 0, rho, 0,
                           0.3, 0.2, 0, 0, 0, 
                           0.1, 0.4, 0, 0, 0,
                           0, 0, 0, 0, rho),5,5,T)
    result[6,1:2]<-rbind(state$p[1:5])%*%result[1:5,1:2]*rdm/state$p[6]
    result[6,3]<-0
    result[6,4]<-(state$p[1:5]%*%result[1:5,4]-state$p[4]*result[2,4])*rdm/state$p[6]
    result[6,5]<-(state$p[1:5]%*%result[1:5,5]-state$p[4]*result[5,5])*rdm/state$p[6]
    result
  }
  param$B<-matrix(c(1, 0, 0, 0, 0,
                    0, 1, 0, 0, 0,
                    0, 0, 1, 0, 0,
                    0, 0, 0, 1, 1,
                    0, 0, 0, rho, 0,
                    0, 0, 1, 0, 0),6,5,TRUE)
  param$S0Exg<-matrix(NA,6,5)
  param$S0Exg[3,3]<-100
  param$S0Exg[6,3]<-100
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

#fixed assets
Example5.6<-function(){
  param<-c()

  param$A<-matrix(c(0.5, 0.9, 1, 0.5, 0.5,
                    0.6, 0, 0, 0, 0,
                    0.2, 0.1, 0, 0.4, 0.8,
                    0, 0, 0, 0.6, 0,
                    0, 0, 0, 0, 0.6),5,5,TRUE)
  param$B<-matrix(c(1, 0, 0, 1, 1, 
                    0, 1, 0, 0, 0,
                    0, 0, 1, 0, 0,
                    0.6, 0, 0, 0, 0,
                    0, 0, 0, 0.6, 0.6),5,5,TRUE)
  param$S0Exg<-matrix(NA,5,5)
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

#pollution
Example5.10<-function(){
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,3,3)
    result[,1]<-c(0.5, 0.5, 0.1)
    result[,2]<-c(0.1, 0, 0.1)
    result[,3]<-CD_A(1,rbind(0.5, 0.5, 0),state$p)
    result
  }
  param$B<-diag(3)
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[2,3]<-30
  param$S0Exg[3,3]<-3
  param$GRExg<-0
  sgm(param)
}

Example5.11<-function(){
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,3,2)
    result[,1]<-CD_A(1,rbind(0,0.5,0.5),state$p)
    result[,2]<-CD_A(1,rbind(0.5,0.5,0),state$p)
    result
  }
  param$B<-matrix(c(
    1, 0, 
    0, 10, 
    0, 1),3,2,TRUE)
  
  param$S0Exg<-matrix(c(
    NA, NA, 
    NA, 30, 
    NA, 3),3,2,TRUE)
  param$GRExg<-0
  sgm(param)
}

Example5.11.2<-function(){
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,4,2)
    result[,1]<-CD_A(1,rbind(0,0.5,0.5,0),state$p)
    result[,2]<-CD_A(1,rbind(0.5,0,0,0.5),state$p)
    result
  }
  param$B<-matrix(c(
    1, 0,
    0, 4,
    0, 1,
    0, 6),4,2,TRUE)
  
  param$S0Exg<-matrix(c(
    NA, NA, 
    NA, 12, 
    NA, 3,
    NA, 18),4,2,TRUE)
  param$GRExg<-0
  sgm(param)
}

#two-country economy
Example6.2.1<-function(){ #see also Example6.8
  #column 1: wheat producer of country 1;
  #column 2: iron producer of country 1;
  #column 3: laborer of country 1;
  #column 4: wheat producer of country 2;
  #column 5: iron producer of country 2;
  #column 6: laborer of country 2;
  #row 1: wheat (of country 1 and 2);
  #row 2: iron (of country 1 and 2);
  #row 3: labor of country 1;
  #row 4: labor of country 2;
  param<-c()
  param$A<-matrix(c(0,   0,   1,   0,   0,   1,
                    0,   0,   1,   0,   0,   1,
                    0.1, 0.4, 0,   0,   0,   0,
                    0,   0,   0,   0.5, 0.5, 0),4,6,TRUE)
  param$B<-matrix(c(1,   0,   0,   1,   0,   0,
                    0,   1,   0,   0,   1,   0,
                    0,   0,   1,   0,   0,   0,
                    0,   0,   0,   0,   0,   1),4,6,TRUE)
  param$S0Exg<-matrix(c(NA,   NA,   NA,   NA,   NA,   NA,
                        NA,   NA,   NA,   NA,   NA,   NA,
                        NA,   NA,   100,  NA,   NA,   NA,
                        NA,   NA,   NA,   NA,   NA,   100),4,6,TRUE)
  param$GRExg<-0
  sgm(param)
}

Example6.2.2<-function(){ 
  param<-c()
  param$A<-matrix(c(0, 0, 1, 
                    0, 0, 1, 
                    0.5, 0.5, 0),3,3,TRUE)
  param$B<-diag(3)
  param$S0Exg<-matrix(c(NA, NA, NA,  
                        NA, NA, NA,  
                        NA, NA, 100),3,3,TRUE)
  param$GRExg<-0
  sgm(param)
}


Example6.3<-function(){ 
  param<-c()
  param$A<-matrix(c(0, 0, 1, 0, 0, 1, 
                    0, 0, 1, 0, 0, 1,
                    0.1, 0.4, 0, 0, 0, 0,
                    0, 0, 0, 0.8, 0.2, 0),4,6,TRUE)
  param$B<-matrix(c(1, 0, 0, 1, 0, 0, 
                    0, 1, 0, 0, 1, 0,
                    0, 0, 1, 0, 0, 0,
                    0, 0, 0, 0, 0, 1),4,6,TRUE)
  param$S0Exg<-matrix(NA,4,6,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,6]<-100
  param$GRExg<-0
  sgm(param)
}


Example6.4<-function(){ 
  param<-c()
  param$A<-matrix(c(0, 0, 1, 0, 0, 1, 
                    0, 0, 1, 0, 0, 1,
                    0.1, 0.4, 0, 0, 0, 0,
                    0, 0, 0, 0.4, 0.1, 0),4,6,TRUE)
  param$B<-matrix(c(1, 0, 0, 1, 0, 0, 
                    0, 1, 0, 0, 1, 0,
                    0, 0, 1, 0, 0, 0,
                    0, 0, 0, 0, 0, 1),4,6,TRUE)
  param$S0Exg<-matrix(NA,4,6,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,6]<-100
  param$GRExg<-0
  param$p0<-rbind(1,1,1,1)
  sgm(param)
}

Example6.5<-function(){ 
  param<-c()
  param$A<-matrix(c(0, 0, 1, 0, 0, 1, 
                    0, 0, 0.25, 0, 0, 1,
                    0.1, 0.4, 0, 0, 0, 0,
                    0, 0, 0, 0.8, 0.2, 0),4,6,TRUE)
  param$B<-matrix(c(1, 0, 0, 1, 0, 0, 
                    0, 1, 0, 0, 1, 0,
                    0, 0, 1, 0, 0, 0,
                    0, 0, 0, 0, 0, 1),4,6,TRUE)
  param$S0Exg<-matrix(NA,4,6,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,6]<-100
  param$GRExg<-0
  param$p0<-rbind(1,1,1,1)
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

Example6.6.1<-function(){ 
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,6,8)
    result[,1]<-CD_A(1,rbind(0,0,0.5,0.5,0,0),state$p)
    result[,2]<-c(0, 0, 0, 0.5, 0, 0)
    result[,3]<-c(1, 1, 0, 0, 0, 0)
    result[,4]<-c(1, 1, 0, 0, 0, 0)
    result[,5]<-CD_A(1,rbind(0,0,0,0,0.5,0.5),state$p)
    result[,6]<-c(0, 0, 0, 0, 0, 0.5)
    result[,7]<-c(1, 0.5, 0, 0, 0, 0)
    result[,8]<-c(1, 0.5, 0, 0, 0, 0)
    result
  }
  param$B<-matrix(c(1, 0, 0, 0, 1, 0, 0, 0,
                    0, 1, 0, 0, 0, 1, 0, 0,
                    0, 0, 1, 0, 0, 0, 0, 0,
                    0, 0, 0, 1, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 1, 0,
                    0, 0, 0, 0, 0, 0, 0, 1),6,8,TRUE)
  param$S0Exg<-matrix(NA,6,8,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,4]<-100
  param$S0Exg[5,7]<-100
  param$S0Exg[6,8]<-100 
  param$GRExg<-0
  sgm(param)
}

#country 1
Example6.6.2<-function(){ 
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,4,4)
    result[,1]<-CD_A(1,rbind(0,0,0.5,0.5),state$p)
    result[,2]<-c(0, 0, 0, 0.5)
    result[,3]<-c(1, 1, 0, 0)
    result[,4]<-c(1, 1, 0, 0)
    result
  }
  param$B<-diag(4)
  param$S0Exg<-matrix(NA,4,4,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,4]<-100
  param$GRExg<-0
  sgm(param)
}

#country 2
Example6.6.3<-function(){ 
  param<-c()
  param$A<-function(state){
    result<-matrix(NA,4,4)
    result[,1]<-CD_A(1,rbind(0,0,0.5,0.5),state$p)
    result[,2]<-c(0, 0, 0, 0.5)
    result[,3]<-c(1, 0.5, 0, 0)
    result[,4]<-c(1, 0.5, 0, 0)
    result
  }
  param$B<-diag(4)
  param$S0Exg<-matrix(NA,4,4,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,4]<-100
  param$GRExg<-0
  sgm(param)
}

Example6.7<-function(){ 
  param<-c()
  param$A<-matrix(c(0,   0,   1, 0,   0,   1, 
                    0.5, 0.5, 0, 0.5, 0.5, 0,
                    0.4, 0.2, 0, 0,   0,   0,
                    0,   0,   0, 0.2, 0.08, 0),4,6,TRUE)
  param$B<-matrix(c(1, 0, 0, 1, 0, 0,
                    0, 1, 0, 0, 1, 0,
                    0, 0, 1, 0, 0, 0,
                    0, 0, 0, 0, 0, 1),4,6,TRUE)
  param$S0Exg<-matrix(NA,4,6,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,6]<-100 #1e-6
  param$GRExg<-0
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

Example6.9<-function(){ 
  param<-c()
  taxRate<-0.05
  param$A<-function(state) {
    matrix(c(0, 0, 1, 0, 0, 0, 1,
             0, 0, 1, 0, 0, 1, 0,
             0.1, 0.4, 0, 0, 0, 0, 0,
             0, 0, 0, 0.5, 0.5, 0, 0,
             0, 0, 0, 0, 0, 1, 0,
             0, 0, 0, 0, 0, 0, state$p[1]*taxRate/state$p[6]),6,7,TRUE)
  }
  param$B<-matrix(c(1, 0, 0, 0, 0, 0, 0,
                    0, 1, 0, 0, 1, 0, 0,
                    0, 0, 1, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 1, 0,
                    0, 0, 0, 1, 0, 0, 1,
                    0, 0, 0, 1, 0, 0, 0),6,7,TRUE)
  param$S0Exg<-matrix(NA,6,7,TRUE)
  param$S0Exg[3,3]<-100
  param$S0Exg[4,6]<-100
  param$GRExg<-0
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

Example6.10<-function(){
  param<-c()
  b<-2/3
  sigma<-rbind(-1,-1,-1,-1)
  alpha<-rbind(1,1,1,1)
  Beta<-matrix(c(0, 1, 0, 1, 
                 b, 0, 0, 0,
                 1, 0, 0, 0,
                 0, 0, 1, 0),4,4,TRUE)
  
  param$A<-function(state){CES_A(sigma,alpha,Beta,state$p)}
  param$B<-diag(4)
  param$S0Exg<-matrix(NA,4,4,T) 
  param$S0Exg[2,2]<-100
  param$S0Exg[4,4]<-100
  param$GRExg<-0
  sgm(param)
}

Example6.11<-function(){ 
  param<-c()
  param$A<-matrix(c(0, 0, 1, 0, 0, 1,
             0, 0, 1, 0, 0, 1,
             0.1, 0.4, 0, 0, 0, 0,
             0, 0, 0, 0.5, 0.5, 0),4,6,TRUE)
  param$B<-matrix(c(1, 0, 0, 1, 0, 0, 
                    0, 1, 0, 0, 1, 0,
                    0, 0, 1, 0, 0, 0,
                    0, 0, 0, 0, 0, 1),4,6,TRUE)
  param$S0Exg<-matrix(NA,4,6,TRUE)
  param$S0Exg[3,3]<-1000
  param$S0Exg[4,6]<-100
  param$GRExg<-0
  sgm(param)
}


Example6.13<-function(){
  param<-c()
  
  param<-c()
  param$A<-function(state){
    alpha<-rep(1,6)
    Beta<-matrix(c(
      0,   0,   1, 0,   0,   1,
      0.5, 0.5, 0, 0.5, 0.5, 0,
      0.5, 0.5, 0, 0,   0,   0,
      0,   0,   0, 0.5, 0.5, 0),4,6,TRUE)
    tmpA<-CD_A(alpha,Beta,state$p)
    tmpA%*%dg(c(state$z[1:2]^-0.25,1,state$z[4:5]^-0.25,1))}
  param$B<-matrix(c(1,   0,   0,   1,   0,   0,
                    0,   1,   0,   0,   1,   0,
                    0,   0,   1,   0,   0,   0,
                    0,   0,   0,   0,   0,   1),4,6,TRUE)
  param$S0Exg<-matrix(c(NA,   NA,   NA,   NA,   NA,   NA,
                        NA,   NA,   NA,   NA,   NA,   NA,
                        NA,   NA,   100,  NA,   NA,   NA,
                        NA,   NA,   NA,   NA,   NA,   100),4,6,TRUE)
  param$GRExg<-0
  param$showIterationNumber<-1
  param$numberOfPeriods<-150
  param$iterationCount<-1
  #param$z0<-c(100,100,100,100,100,100)#(i)
  param$z0<-c(200,100,100,100,200,100)#(ii)
  #param$z0<-c(100,200,100,200,100,100)#(iii)
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

Example7.1<-function(){
  param<-c()
  alpha<-rbind(1,1,1)
  Beta<-matrix(c(0.64, 0.4, 0.4, 
                 0.16, 0.4, 0.4,
                 0.2, 0.2, 0.2),3,3,TRUE)
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(3)
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[1,1]<-100
  param$S0Exg[2,2]<-100
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  sgm(param)
}

Example7.2<-function(){
  #column 1: wheat producer;
  #column 2: laborer;
  #column 3: money owner;
  #row 1: wheat;
  #row 2: labor;
  #row 3: money;
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-3
  
  alpha<-rbind(1,1,1)
  Beta<-matrix(c(0.5,  0.5, 0.5,
                 0.5,  0.5, 0.5,
                 -1,   -1,  -1),3,3,TRUE) 
  
  param$A<-function(state){CD_mA(alpha,Beta,state$p)}
  param$B<-diag(3)
  
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[2,2]<-100;   param$S0Exg[3,3]<-100
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.25)#(i) 
  #param$pExg<-rbind(NA, NA, 1e-6) #(ii) 
  sgm(param)  
}

Example7.3<-function(){
  #column 1: wheat producer;
  #column 2: laborer;
  #column 3: money owner;
  #row 1: wheat;
  #row 2: labor;
  #row 3: money;
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-3
  tmpA<-matrix(c(0.5, 1, 1,
                 0.1, 0, 0,
                 -1, -1, -1),3,3,TRUE)
  
  param$A<-function(state){Leontief_mA(tmpA,state$p)}
  param$B<-diag(3)
  
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[2,2]<-100; param$S0Exg[3,3]<-100
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.25)
  sgm(param)
}

Example7.4<-function(){
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-3
  alpha<-rbind(1,1,1)
  Beta<-matrix(c(0.5, 0.5, 0.5, 
                 0.5, 0.5, 0.5,
                 -1, -1, -1),3,3,TRUE)
  
  param$A<-function(state){CD_mA(alpha,Beta,state$p)}
  param$B<-diag(3)
  
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[2,2]<-100; param$S0Exg[3,3]<-100
  param$GRExg<-0.1
  param$pExg<-rbind(NA, NA, 0.25)
  sgm(param)
}


Example7.5<-function(){
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-3
  r<-rs<-0.25
  
  alpha<-rbind(1,1,1,1)
  Beta<-matrix(c(0.5,  0.5, 0.5, 0.5,
                 0.5,  0.5, 0.5, 0.5,
                 -1,   -1,  -1,  -1),3,4,TRUE) 
  
  param$A<-function(state){
    result<-matrix(0,4,4)
    result[1:3,]<-CD_mA(alpha,Beta,state$p[1:3])
    result[4,1]<-result[3,1]*(1+r)*rs/state$p[4]
    result}
  param$B<-diag(4)
  
  param$S0Exg<-matrix(NA,4,4)
  param$S0Exg[2,2]<-param$S0Exg[3,3]<-
    param$S0Exg[4,4]<-100
  param$GRExg<-0.1 #(i) 0 (ii) 0.1
  param$pExg<-rbind(NA, NA, r,NA)
  sgm(param)  
}

Example7.5.2<-function(){
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-3
  r<-rs<-0.1423 
  
  alpha<-rbind(1,1,1)
  Beta<-matrix(c(0.5,  0.5, 0.5,
                 0.5,  0.5, 0.5,
                 -1,   -1,  -1),3,3,TRUE) 
  
  param$A<-function(state){
    result<-matrix(0,4,3)
    result[1:3,]<-CD_mA(alpha,Beta,state$p[1:3])
    result[4,1]<-result[3,1]*(1+r)*rs/state$p[4]
    result}
  param$B<-matrix(c(1,  0, 0,
                    0,  1, 1,
                    0,  0, 10,
                    0,  0, 10),4,3,TRUE)
  
  param$S0Exg<-matrix(c(NA,  NA, NA,
                        NA,  99, 1,
                        NA,  NA, 100,
                        NA,  NA, 100),4,3,TRUE)
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, r,NA)
  sgm(param)  
}

#foreign exchange rate
Example7.6<-function(){
  #column 1: wheat producer of country 1;
  #column 2: laborer of country 1;
  #column 3: money owner of country 1;
  #column 4: iron producer of country 2;
  #column 5: laborer of country 2;
  #column 6: money owner of country 2;
  #row 1: wheat (of country 1);
  #row 2: labor of country 1;
  #row 3: money of country 1;
  #row 4: iron (of country 2);
  #row 5: labor of country 2;
  #row 6: money of country 2;
  param<-c()
  param$moneyOwnerIndx<-rbind(3,6); param$moneyIndx<-rbind(3,6)
  
  alpha<-matrix(1,6,1)
  Beta<-matrix(c(0,   1,  1,   0,   1,   1,
                 0.5, 0,  0,   0,   0,   0,
                 -1, -1, -1,   0,   0,   0,
                 0.5, 0,  0,   0.5, 0,   0,
                 0,   0,  0,   0.5, 0,   0,
                 0,   0,  0,  -1,  -1,  -1),6,6,TRUE)
  param$A<-function(state) CD_mA(alpha,Beta,state$p)
  #param$A<-function(state){CES_mA(-1*ones(6,1),alpha,Beta,state$p)}
  param$B<-diag(6)
  
  param$S0Exg<-matrix(NA,6,6)
  param$S0Exg[2,2]<-100
  param$S0Exg[3,3]<-600
  param$S0Exg[5,5]<-100
  param$S0Exg[6,6]<-100
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.1, NA, NA, 0.1)
  sgm(param)
}

#foreign exchange rate
Example7.7<-function(){
  param<-c()
  param$moneyIndx<-rbind(4,6,8); param$moneyOwnerIndx<-rbind(4,8,12)
   param$A<-function(state){
    result<-matrix(NA,8,12)
    result[,1]<-result[,2]<-CES_mA(-1,10,rbind(0,1,1,-1,0,0,0,0),state$p)
    result[,3]<-result[,4]<-Leontief_mA(rbind(1,0,0,-1,0,0,0,0),state$p)
    result[,5]<-result[,6]<-CES_mA(-1,10,rbind(0,1,0,0,1,-1,0,0),state$p)
    result[,7]<-result[,8]<-Leontief_mA(rbind(1,0,0,0,0,-1,0,0),state$p)
    result[,9]<-result[,10]<-CES_mA(-1,10,rbind(0,1,0,0,0,0,1,-1),state$p)
    result[,11]<-result[,12]<-Leontief_mA(rbind(1,0,0,0,0,0,0,-1),state$p)
    result
    }
  param$B<-matrix(0,8,12)
  param$B[1,1]<-param$B[2,2]<-param$B[3,3]<-param$B[4,4]<-
    param$B[1,5]<-param$B[2,6]<-param$B[5,7]<-param$B[6,8]<-
    param$B[1,9]<-param$B[2,10]<-param$B[7,11]<-param$B[8,12]<-1
  
  param$S0Exg<-matrix(NA,8,12)
  param$S0Exg[3,3]<-param$S0Exg[4,4]<-param$S0Exg[5,7]<-
    param$S0Exg[6,8]<-param$S0Exg[7,11]<-param$S0Exg[8,12]<-100; 
  param$GRExg<-0; 
  #param$p0<-rbind(10,0.08749,0.4031,0.01,0.2448,0.4,0.1611,0.8); 
  param$pExg<-rbind(NA, NA, NA, 0.01, NA, 0.4, NA, 0.8)
  sgm(param)
}


#commodity money
Example7.8<-function(){
  param<-c()
  param$GRExg<-0
  
  dv<-0.2;
  #(i) rd<-1e-6; rr<-1; tau<-1e-6 #7.8.1
  #(ii) rd<-0; rr<-1;tau<-1; #7.8.2
  #(iii) rd<-0.1; rr<-0.5; tau<-0 #7.9
  rd<-0.1; rr<-0.5; tau<-1e-6
  
  param$A<-function(state){
    p1<-state$p[1]/state$p[2];p2<-1;p3<-state$p[3]/state$p[2];
    r<-state$p[4]/state$p[2]; ps<-state$p[5]/state$p[2];
    pt<-state$p[6]/state$p[2];
    matrix(c(0, 0, 1, 0,
             0, 0, 0, 1,
             1, 1, 0, 0,
             p3,p3, p1, dv,
             rd*(1+tau)*(1+r)*p3/ps, rd*(1+tau)*(1+r)*p3/ps, 0,rd*(1+tau)*(p2+r*dv)/ps,
             0, tau*(1+r)*p3/pt, 0, 0
    ),6,4,T)
  }
  param$B<-matrix(c(1, 0, 0, 0,
                    0, 1, 0, 1-dv,
                    0, 0, 1, 0,
                    0, 0, 0, 1/rr,
                    0, 0, 1, 0,
                    0, 0, 1, 0),6,4,TRUE)
  param$S0Exg<-matrix(NA,6,4)
  param$S0Exg[3,3]<-param$S0Exg[5,3]<-100
  param$S0Exg[6,3]<-100
  param$priceAdjustmentVelocity<-0.008
  param$p0<-rbind(1, 1, 1, 0.2, 1, 1)
  param$tolCond<-1e-5
  sgm(param)
}

#positive growth
Example7.9X<-function(){
  param<-c()
  param$GRExg<-0.01
  
  dv<-0.2;#!!!
  money.dv<-1-(1-dv)/(1+param$GRExg)
  #(i) rd<-0; rr<-1;tau<-0; #7.8.1
  #(ii) rd<-0; rr<-1;tau<-1; #7.8.2
  #(iii) rd<-0.1; rr<-0.5; tau<-0 #7.9
  rd<-0.1; rr<-0.5; 
  mm<-1/rr
  
  param$A<-function(state){
    p1<-state$p[1]/state$p[2];p2<-1;p3<-state$p[3]/state$p[2];
    r<-state$p[4]/state$p[2]; ps<-state$p[5]/state$p[2];
    
    alpha<-rbind(1,1,1)
    Beta<-matrix(c(0.5,  0.5, 0.5,
                   0,    0,   0,
                   0.5,  0.5, 0.5,
                   -1,   -1,  -1),4,3,TRUE) 
    result<-matrix(0,5,4)
    result[1:4,1:3]<-CD_mA(alpha,Beta,c(p1,p2,p3,r))
    result[1:4,4]<-c(0,1,0,money.dv)
    result[5,1:4]<-c(rd*(1+r)*p3/ps, 
                     rd*(1+r)*p3/ps, 0,rd*(1+r*money.dv)/ps)
    result
  }
  param$B<-matrix(c(1, 0, 0, 0,
                    0, 1, 0, 1-dv,
                    0, 0, 1, 0,
                    0, 0, 0, mm,
                    0, 0, 1, 0),5,4,TRUE)
  param$S0Exg<-matrix(NA,5,4)
  param$S0Exg[3,3]<-param$S0Exg[5,3]<-100
  
  param$priceAdjustmentVelocity<-0.1
  param$p0<-rbind(1, 1, 1, 0.2, 1)
  param$tolCond<-1e-5
  sgm(param)
}

Example7.10<-function(){
  param<-c()
  param$GRExg<-0
  rd<-0; rr<-0.5
  rfm<-0.05;
  
  param$moneyIndx<-2; param$moneyOwnerIndx<-2
  
  param$A<-function(state){
    matrix(c(0, 1, 1, 0,
             0, 0, 0, rr,
             1, 0, 0, 0,
             state$p[3],
             state$p[1], 
             state$p[1],
             0),4,4,T)
  }
  param$B<-matrix(c(1, 0, 0, 0,
                    0, 1, 0, 0,
                    0, 0, 1, 0,
                    0, 0, 0, 1),4,4,TRUE)
  param$S0Exg<-matrix(NA,4,4)
  param$S0Exg[3,3]<-100
  param$S0Exg[2,2]<-100
  param$pExg<-rbind(NA,rfm,NA,NA)
  param$priceAdjustmentVelocity<-0.01
  sgm(param)
}

Example7.10.2<-function(){
  param<-c()
  param$GRExg<-0
  rd<-0; rr<-0.5
  rfm<-0.05; mm<-1/rr;
  
  param$moneyIndx<-2; param$moneyOwnerIndx<-2
  
  param$A<-function(state){
    matrix(c(0, 1, 1, 
             state$p[3]/mm, state$p[1]/mm, state$p[1]/mm, 
             1, 0, 0),3,3,T)
  }
  param$B<-matrix(c(1, 0, 0, 
                    0, 1, 0, 
                    0, 0, 1),3,3,TRUE)
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[3,3]<-100
  param$S0Exg[2,2]<-100
  param$pExg<-rbind(NA,rfm,NA)
  param$priceAdjustmentVelocity<-0.01
  sgm(param)
}

#Bond
Example7.11<-function(){
  param<-c()
  param$GRExg<-0
  r<-0.1
  labor.input<-0
  param$moneyIndx<-4; param$moneyOwnerIndx<-4
  
  param$A<-function(state){
    matrix(c(0, 1, 1, 1, #wheat
             1, 0, 0, 0, #labor
             0, 0,(1+r)*state$p[1]/state$p[3], 0, 
             
             state$p[2], state$p[1], state$p[1], state$p[1]
    ),4,4,T)
  }
  param$B<-matrix(c(1, 0, 0, 0,
                    0, 1, 1, 0,
                    0, 1, 0, 0,
                    0, 0, 0, 100),4,4,TRUE)
  param$S0Exg<-matrix(NA,4,4)
  param$S0Exg[2,2]<-param$S0Exg[2,3]<-param$S0Exg[4,4]<-100
  param$S0Exg[3,2]<-100
  param$pExg<-rbind(NA,NA,NA,r)
  param$priceAdjustmentVelocity<-0.01
  sgm(param)
}

#exchange rate and international credit
Example7.12<-function(){
  param<-c()
  param$moneyOwnerIndx<-rbind(3,6); param$moneyIndx<-rbind(3,6)
  
  alpha<-matrix(1,6,1)
  Beta<-matrix(c(0,   1,  1,   0,   1,   0,
                 0.5, 0,  0,   0,   0,   0,
                 -1, -1, -1,   0,   0,   0,
                 0.5, 0,  0,   0.5, 0,   0,
                 0,   0,  0,   0.5, 0,   0,
                 0,   0,  0,  -1,  -1,   0, 
                 0,   0,  0,   0,   0,   1),7,6,TRUE)
  param$A<-function(state) CD_mA(alpha,Beta,state$p)
  
  param$B<-diag(6)
  param$B<-rbind(param$B,c(0, 0, 1, 0, 0, 0))
  
  param$S0Exg<-matrix(NA,7,6)
  param$S0Exg[2,2]<-100
  param$S0Exg[3,3]<-600
  param$S0Exg[5,5]<-100
  param$S0Exg[6,6]<-100
  param$S0Exg[7,3]<-1
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.1, NA, NA, 0.1) #!!!!!!!!
  sgm(param)
}

#bank
Example7.13<-function(){
  param<-c()
  param$GRExg<-0
  r<-0.1
  rr<-0.2#(i) 0 (ii) 0.2
  labor.input<-0
  param$moneyIndx<-5; param$moneyOwnerIndx<-4
  
  param$A<-function(state){
    matrix(c(0, 1, 1, 1, 0,#wheat
             1, 0, 0, 0, 0,#labor
             0, 0, 0, 0, 1, #deposit
             0, 0, (1+r)*state$p[1]/state$p[4],0,0, #credit
             #money
             state$p[2], state$p[1], state$p[1],state$p[1],0,
             #reserve
             0, 0, 0, 0, rr*state$p[3]/state$p[6]),6,5,T)
  }
  param$B<-matrix(c(1, 0, 0, 0, 0,
                    0, 1, 1, 0, 0,
                    0, 1, 0, 0, 0,
                    0, 0, 0, 0, 1,
                    0, 0, 0, 100, 0,
                    0, 0, 0, 1, 0),6,5,TRUE)
  param$S0Exg<-matrix(NA,6,5)
  param$S0Exg[2,2]<-param$S0Exg[2,3]<-param$S0Exg[5,4]<-100
  param$S0Exg[3,2]<-100
  param$S0Exg[6,4]<-1
  param$pExg<-rbind(NA,NA,NA, NA, r,NA)
  
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

#shadow price
Example7.14<-function(){
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-2
  
  alpha<-rbind(1,1)
  Beta<-matrix(c(0.5,  0.5, 
                 0.5,  0.5,
                 -1,   -1),3,2,TRUE)
  param$A<-function(state){
    CD_mA(alpha,Beta,state$p)
  }
  param$B<-matrix(c(1,0,
                    0,100,
                    0,100),3,2,T)
  
  param$S0Exg<-matrix(NA,3,2)
  param$S0Exg[2,2]<-100
  param$S0Exg[3,2]<-100
  #param$S0Exg[1,2]<- 10
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.25)
  sgm(param)
}

#shadow price and international trade
Example7.15<-function(){
  param<-c()
  param$moneyIndx<-rbind(3,4); param$moneyOwnerIndx<-rbind(2,4)
  
  alpha<-rbind(1,1,1,1)
  Beta<-matrix(c(0.5,  0.5, 0.5, 0.5,
                 0.5,  0.5, 0.5, 0.5,
                 -1,   -1,  0,   0,
                 0,    0,   -1,  -1),4,4,TRUE) 
  
  param$A<-function(state){
    CD_mA(alpha,Beta,state$p)}
  param$B<-matrix(c(1,0,  1,0,
                    0,100,0,100,
                    0,100,0,0,
                    0,0,  0,100),4,4,T)
  
  param$S0Exg<-matrix(c(NA,NA, NA,NA,
                        NA,100,NA,100,
                        NA,100,NA,NA,
                        NA,NA, NA,100),4,4,T)
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.25,0.1)
  sgm(param)
}

#equilibrium coffee problem
Example8.1<-function(){
  param<-c()
  param$A<-matrix(c(
    0.05, 0.05, 0.1,
     0.1, 0, 0.1,
     0, 0.15, 0.05
  ),3,3,TRUE)
  param$B<-matrix(0,3,3)
  param$S0Exg<-diag(3)
  param$GRExg<-0;
  sgm(param)
}

Example8.2<-function(){
  param<-c()
  param$S0Exg<-diag(c(100,60,100))
  param$GRExg<-0;
  alpha<-c(5,3,1);
  Beta<-matrix(c(0.6, 0.4, 0.2,
                 0.1, 0.4, 0.7,
                 0.3, 0.2, 0.1),3,3,TRUE)
  
  param$A<-function(state){CD_A(alpha,Beta,state$p)};
  param$B<-param$S0Exg;
  sgm(param)
}

Example8.7<-function(){
  param<-c()
  param$A<-matrix(c(
    0.05, 0.05, 0.1,
    0.1, 0, 0.1,
    0, 0.15, 0.05
  ),3,3,TRUE)
  param$B<-matrix(0,3,3)
  param$S0Exg<-diag(3)
  param$GRExg<-0;
  param$p0<-rbind(1,1,1)
  param$showIterationNumber<-1
  param$numberOfPeriods<-300
  param$iterationCount<-1
  ge<-sgm(param)
}

Example8.8<-function(){
  param<-c()
  param$moneyOwnerIndx<-4; param$moneyIndx<-4
  param$pExg<-rbind(NaN, NaN, NaN, 0.25)
  param$A<-function(state){
    tmpA<-matrix(c(
      0.05, 0.05, 0.1,  0.1,
      0.1,  0,    0.1,  0.1,
      0,    0.15, 0.05, 0.1,
      -1,   -1,   -1,   -1),4,4,TRUE)
    Leontief_mA(tmpA,state$p)
    }
  param$B<-matrix(0,4,4)
  param$S0Exg<-diag(4)
  param$GRExg<-0
  param$depreciationCoef<-0
  param$showIterationNumber<-1
  param$iterationCount<-1
  param$numberOfPeriods<-800
  param$p0<-rbind(0.5,0.5,0.5,0.25)
  ge<-sgm(param)
}

Example8.9<-function(){
  param<-c()
  param$moneyOwnerIndx<-c(4,5); param$moneyIndx<-c(4,5)
  param$pExg<-rbind(NaN, NaN, NaN, 0.25, 0.25)
  param$A<-function(state){
    tmpA<-matrix(c(
      0.05, 0.05, 0.1,  0.1, 0.1,
      0.1,  0,    0.1,  0.1, 0.1,
      0,    0.15, 0.05, 0.1, 0.1,
      -1,   -1,   0,    -1,  0,
      0,    0,    -1,   0,   -1),5,5,TRUE)
    Leontief_mA(tmpA,state$p)
  }
  param$B<-matrix(0,5,5)
  param$S0Exg<-diag(5)
  param$S0Exg[4,4]<-3
  param$GRExg<-0
  param$depreciationCoef<-0
  param$showIterationNumber<-1
  param$iterationCount<-1
  param$numberOfPeriods<-800
  param$p0<-rbind(0.5,0.5,0.5,0.25,0.25)
  param$e0<-rbind(1,1)
  ge<-sgm(param)
}

Example9.3<-function(){
  param<-c()
  param$A<-matrix(c(
    56/115, 6,
    12/575, 2/5
  ),2,2,TRUE)
  param$B<-diag(2)
  param$showIterationNumber<-1
  param$iterationCount<-1
  param$numberOfPeriods<-100
  param$p0<-rbind(1/15,1)
  param$z0<-rbind(575,20)
  param$thresholdForPriceAdjustment<-0.99
  param$priceAdjustmentMethod<-"fixed"
  param$priceAdjustmentVelocity<-0.02
  ge<-sgm(param)
}

Example9.4<-function(){
  param<-c()
  param$A<-matrix(c(
    56/115, 6,
    12/575, 2/5
  ),2,2,TRUE)
  param$B<-diag(2)
  param$S0Exg<-matrix(c(NA,NA,
                        NA,190),2,2,T)
  param$GRExg<-0
  param$showIterationNumber<-1
  param$iterationCount<-1
  param$numberOfPeriods<-1000
  param$p0<-rbind(12/295,1)
  param$z0<-rbind(3400,90)
  param$thresholdForPriceAdjustment<-0.99
  param$priceAdjustmentMethod<-"variable"
  param$priceAdjustmentVelocity<-0.2
  ge<-sgm(param)
}

Example9.5<-function(){
  param<-c()
  alpha<-rbind(1,1,1)
  Beta<-matrix(c(0,  1, 1,
                 0.5,0, 0,
                 0.5,0, 0),3,3,TRUE)
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(3)
  param$S0Exg<-matrix(c(NA,NA ,NA,
                        NA,100,NA,
                        NA,NA,100),3,3,T)
  param$GRExg<-0
  param$pExg<-rbind(1, NA, 0.625)#(i)
  #param$pExg<-rbind(1, 0.25, 0.25)#(ii)
  param$showIterationNumber<-1
  param$iterationCount<-1
  param$numberOfPeriods<-200
  param$depreciationCoef<-0
  sgm(param)
}

Example9.6<-function(){
  param<-c()
  alpha<-rbind(1.2,1)
  Beta<-matrix(c(0.5,1,
                 0.5,0),2,2,TRUE)
  param$A<-function(state){CD_A(alpha,Beta,state$p)}
  param$B<-diag(2)
  param$S0Exg<-matrix(c(NA,NA,
                        NA,100),2,2,T)
  param$GRExg<-0
  param$showIterationNumber<-1
  param$numberOfPeriods<-100
  param$z0<-rbind(50,50)
  param$p0<-rbind(1,0.25)
  param$depreciationCoef<-1
  #param$depreciationCoef<-0.5
  sgm(param)
}

Example9.7<-function(){
  param<-c()
  param$A<-matrix(c(0,   0, 1,
                    0.4, 0, 0,
                    0.4, 1, 0),3,3,TRUE)
  param$B<-matrix(c(1,   0, 0,
                    0.36, 1, 0,
                    0,   0, 1),3,3,TRUE)
  param$S0Exg<-matrix(NA,3,3,TRUE)    
  
  param$S0Exg[3,3]<-100
  param$GRExg<-0
  param$showIterationNumber<-1
  param$numberOfPeriods<-800
  param$iterationCount<-1
  param$priceAdjustmentVelocity<-0.05
  sgm(param)
}

Example9.10<-function(){
  param<-c()
  param$moneyIndx<-3; param$moneyOwnerIndx<-3
  tmpA<-matrix(c(0.5, 0.5, 0.5,
                 0.5, 0.5, 0.5,
                 -1, -1, -1),3,3,TRUE)#-1 denotes the demand for money
  
  param$A<-function(state){Leontief_mA(tmpA,state$p)}
  param$B<-diag(3)
  
  param$S0Exg<-matrix(NA,3,3)
  param$S0Exg[2,2]<-100; param$S0Exg[3,3]<-100
  param$GRExg<-0
  param$pExg<-rbind(NA, NA, 0.25)
  param$p0<-rbind(0.625, 0.375, 0.25)
  param$z0<-rbind(95, 100, 100)
  param$showIterationNumber<-1
  param$thresholdForPriceAdjustment<-0.99
  param$priceAdjustmentVelocity<-0.3
  param$numberOfPeriods<-1000
  param$iterationCount<-1
  param$enableDisp<-0
  sgm(param)
}

a.random.economy.including.100.sectors<-function(){
  n<-100  #sector count
  param<-c()
  
  #param$A<-matrix(runif(n^2)/(2*n),n) #Leontief-type
  
  alpha<-10*n*runif(n); Beta<-matrix(runif(n^2),n) #CD-type
  Beta<-Beta%*%diag(1/colSums(Beta))
  param$A<-function(state) CD_A(alpha,Beta,state$p) 
  param$B<-diag(n);
  
  param$S0Exg<-matrix(NA,n,n)
  for (k in 91:n)  param$S0Exg[k,k]<-100
  param$GRExg<-0;
  param$numberOfPeriods<-1000
  param$iterationCount<-5
  
  param$priceAdjustmentVelocity<-0.15
  ge<-sgm(param)
}


dispGE<-function(){
  print('The equilibrium price vector ge$p is ')
  print(ge$p)
  print('ge$z is')
  print(ge$z)
  print('The equilibrium supply matrix ge$S is')
  print(ge$S)
  print('The equilibrium input coefficient matrix ge$A is')
  print(ge$A)
  print('The equilibrium input matrix ge$A*diag(ge$z) is')
  print(ge$A%*%dg(ge$z))
  if (!is.null(ge$ex)){
    print('The equilibrium foreign exchange rate ge$ex is')
    print(ge$ex)
  }
}

